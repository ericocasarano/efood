import { useParams } from 'react-router-dom'
import Header from '../../components/Header'
import BannerPerfil from '../../components/BannerPerfil'
import ItemListPerfil from '../../components/ItemListPerfil'
import { useGetMenuQuery } from '../services/api'

const Perfil = () => {
  const { id } = useParams()
  const { data: perfil } = useGetMenuQuery(id!)

  return (
    <>
      <Header />
      <BannerPerfil
        tituloRestaurante={perfil ? perfil.titulo : 'Carregando...'}
        tipoRestaurante={perfil ? perfil.tipo : 'Carregando...'}
      />
      {perfil ? (
        <ItemListPerfil perfilRestaurantes={[perfil]} />
      ) : (
        <div>Carregando...</div>
      )}
    </>
  )
}

export default Perfil

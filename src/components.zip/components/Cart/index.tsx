import Button from '../Button'
import {
  Botao,
  CartContainer,
  CartItem,
  Overlay,
  Sidebar,
  TotalValue
} from './styles'
import imagemTeste from '../../assets/images/tratoria-marguerita.png'
import { useSelector } from 'react-redux'
import { RootReducer } from '../../store'

const Cart = () => {
  const { isOpen } = useSelector((state: RootReducer) => state.cart)

  return (
    <CartContainer className={isOpen ? 'is-open' : ''}>
      <Overlay />
      <Sidebar>
        <ul>
          <CartItem>
            <img src={imagemTeste} />
            <div>
              <h3>Pizza Marguerita</h3>
              <span>R$ 60,90</span>
            </div>
            <Botao type="button" />
          </CartItem>
          <CartItem>
            <img src={imagemTeste} />
            <div>
              <h3>Pizza Marguerita</h3>
              <span>R$ 60,90</span>
            </div>
            <Botao type="button" />
          </CartItem>
        </ul>
        <TotalValue>
          <p>Valor total</p>
          <p>R$ 182,70</p>
        </TotalValue>
        <Button title="Clique aqui para continuar com a entrega" type="button">
          Continuar com a entrega
        </Button>
      </Sidebar>
    </CartContainer>
  )
}

export default Cart

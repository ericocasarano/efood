import { ContainerHeader, LinkCart, TituloPerfil } from './styles'
import logo from '../../assets/images/logo.png'
import { Link } from 'react-router-dom'

import { open } from '../../store/reducers/cart'
import { useDispatch } from 'react-redux'

const Header = () => {
  const dispatch = useDispatch()

  const openCart = () => {
    dispatch(open())
  }

  return (
    <ContainerHeader>
      <div className="container">
        <TituloPerfil>Restaurantes</TituloPerfil>
        <Link to="/">
          <img src={logo} alt="efood" />
        </Link>
        <LinkCart onClick={openCart}>0 - produtos(s)</LinkCart>
      </div>
    </ContainerHeader>
  )
}

export default Header
